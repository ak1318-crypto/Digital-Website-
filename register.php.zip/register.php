<?php

session_start();

$name = $_POST["name"];
$email = $_POST["email"];
$username = $_POST["username"];
$password = $_POST["password"];
$hash = password_hash($password,PASSWORD_DEFAULT);


if (!empty($_POST)) {
    $conn = new mysqli("localhost", "ak1318_db_user", "LIL-xan2007", "ak1318_db");
    if ($conn->connect_error) {
        die("connection failed: " . $conn->connect_error);
    }
    $sql = "INSERT INTO users (username, password, Email) VALUES ( '$username', '$hash', '$email')";
    $result = mysqli_query($conn, $sql);
    mysqli_close($conn);
    echo "An account has been created";
}

?>