<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="CSS/style.css">
  
  <link rel="stylesheet" href=" CSS/normalize.css">
<title>Registration Form</title>
</head>
    <body>
        <header class="header">
            <a href="#" class="logo"><i class="fa-solid fa-user-secret"></i>Register</a>
        </header>
        <section id="home" class="home">
            
            <div> 
            <h1>Register Here</h1>
            
            <h4> Takes a couple minute</h4>
            
            
    	<form action="register.php" method="post">
    		Name: <input type="text" name="name">
    		<br>
    		E-mail: <input type="text" name="email">
    		<br>
    		Username: <input type="text" name="username">
    		<br> 
    		Password: <input type="password" name="password">
    		<br> 
    		<input type="submit" name="submit" value="Submit">
    	</form>
    	
    	<p> By clicking on the link you agree to terms and condtions <br>
    	<a href = "#"> Terms and Condition</a>
    	</p>
    	</div>
    	<p> Already have an account? <a href ="https://ak1318.brighton.domains/digitalwebsite/login.php"> Login here</a></p>
    </body>
</html>