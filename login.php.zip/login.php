<?php
    session_start();
    
    if (!empty($_POST)) {
        $conn = new mysqli("localhost", "ak1318_db_user", "LIL-xan2007", "ak1318_db");
        if ($conn->connect_error) {
            die("connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT password FROM users";
        $result = mysqli_query($conn, $sql);
        while ($record = mysqli_fetch_assoc($result)) {
            if ( $record["password"] == $_POST['password']) {
                $_SESSION["status"] = "loggedin";
                header("Location: http://ak1318.brighton.domains/digitalwebsite/index.php#");
                exit();
            }
        }
    }
    // mysqli_close($conn);
?>

<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link rel="stylesheet" href="CSS/style.css">
  
  <link rel="stylesheet" href="CSS/normalize.css">
  
<title>Log-in Page</title>
</head>
    <body>
        <header class="header">
            <a href="#" class="logo"><i class="fa-solid fa-user-secret"></i>Login Page</a>
        </header>
        
        <section id="home" class="home">

    <h2 class="banner">Username</h2>
    <form action="" method="post">
    		<input type="text" style="height:50px;font-size:14pt;" name="username">
    		<br> 
    		
    <h2 class="banner">Password</h2>
    <input type="password" style="height:50px;font-size:14pt;" name="password">
    		<br>
    		<div style = "position:relative; top:20px;">
         <input type="submit"  style="height:50px; width:200px; font-size:10pt; background-color:#5213ec;" value="Log In">
         </div>
         
         <div style = "position:relative; top:40px;">
        
         <button type ="button" onclick ="location.href='https://ak1318.brighton.domains/digitalwebsite/registration_form.php'"> Click here to register </button>
         
         
         
         
    	    
      </div>
    	</form>
    	
    <!--<a href="#"><button>learn more</button></a>-->
    </section>
    </body>
</html>