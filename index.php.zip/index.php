<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Digital | Home</title>

    <!-- font auwesome cdn link -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">


    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='CSS/style.css'>
    <link rel="stylesheet" href="CSS/normalize.css">

    <link rel="icon" type="image/x-icon" href="images/atom.png">

    <!-- <script src='main.js'></script> -->
</head>
<body>


<!-- header section start -->
<header>

    <input type="checkbox" name="" id="toggler">
    <label for="toggler" class="fa-solid fa-bars-staggered"></label>



    <a href="#" class="logo">Digital.<span></span></a>
    <nav class="navbar">
        <a href="#home">home</a>
        <a href="#about">about</a>
        <a href="#product">products</a>
        <a href="#review">reviews</a>
        <a href="#contact"> contact</a>
    </nav>

    <div class="icons">
        <a href="#" class="fas fa-heart"></a>
        <a href="#" class="fas fa-shopping-cart"></a>
        <a href= "https://ak1318.brighton.domains/digitalwebsite/login.php#" class="fas fa-user"></a>
        <a href= "https://ak1318.brighton.domains/digitalwebsite/registration_form.php" class="fas fa-user"></a>
    </div>
    

</header>

<!-- header section ends -->

<!-- home section starts -->
<section class="home" id="home">

    <div class="content">

        <h3>sleek powerful laptops</h3>
        <span>Powerful. Portable. Productive.</span>
        <p>Elevate your digital experience with our innovative laptops. Designed to inspire creativity, maximize productivity, and deliver exceptional performance wherever you go</p>
         <a href="#product"class="btn">shop now</a>

    </div>
</section>
<!-- home section ends -->
<!-- about section starts -->
<section class="about" id="about">

    <h1 class="heading"><span>about</span> us</h1>

    <div class="row">

        <div class="video-container">
            <video src="images/Laptop-video03.mp4" loop autoplay muted></video>
            <h3>best laptop sellers</h3>
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p>We sell high-quality, reliable laptops that'll meet all your needs</p>
            <p>laptops are a must-have tool for anyone who needs to work, study, or stay connected on the go.</p>
            <a href="#" class="btn">Learn more</a>
        </div>

    </div>

</section>
<!-- about section ends -->

<!-- icon section start -->
<section class="icons-container">

    <div class="icons">
        <img src="images/delivery.png" alt="">
        <div class="info">
            <h3>free delivery</h3>
            <span>on all orders</span>
        </div>
    </div>

    <div class="icons">
        <img src="images/cashback.png" alt="">
        <div class="info">
            <h3>10 day returns</h3>
            <span>moneyback guarantee</span>
        </div>
    </div>

    <div class="icons">
        <img src="images/gift-card.png" alt="">
        <div class="info">
            <h3>offer & gifts</h3>
            <span>on all orders</span>
        </div>
    </div>

    <div class="icons">
        <img src="images/credit-card.png" alt="">
        <div class="info">
            <h3>secure payments</h3>
            <span>protected by paypal</span>
        </div>
    </div>

</section>
<!-- icon section ends -->


<!-- product section start -->

<section class="product" id="product">
    <h1 class="heading">Latest <span> products</span></h1>

    <div class="box-container">
        <div class="box">
            <span class="discount">-10%</span>
            <div class="image">
                <img src="images/product01.png" alt="">
                <div class="icons">
                    <a href="#"class="fas fa-heart"></a>
                    <a href="#"class="cart-btn">add to cart</a>
                    <a href="#"class="fas fa-share"></a>
                </div>
                <div class="content">
                    <h3>HP Laptop</h3>
                    <div class="price">£250.00 <span>£300.00</span></div>
                </div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-15%</span>
            <div class="image">
                <img src="images/product02.png" alt="">
                <div class="icons">
                    <a href="#"class="fas fa-heart"></a>
                    <a href="#"class="cart-btn">add to cart</a>
                    <a href="#"class="fas fa-share"></a>
                </div>
                <div class="content">
                    <h3>HP Laptop</h3>
                    <div class="price">£250.00 <span>£300.00</span></div>
                </div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-5%</span>
            <div class="image">
                <img src="images/product02.png" alt="">
                <div class="icons">
                    <a href="#"class="fas fa-heart"></a>
                    <a href="#"class="cart-btn">add to cart</a>
                    <a href="#"class="fas fa-share"></a>
                </div>
                <div class="content">
                    <h3>HP Laptop</h3>
                    <div class="price">£250.00 <span>£300.00</span></div>
                </div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-20%</span>
            <div class="image">
                <img src="images/product04.png" alt="">
                <div class="icons">
                    <a href="#"class="fas fa-heart"></a>
                    <a href="#"class="cart-btn">add to cart</a>
                    <a href="#"class="fas fa-share"></a>
                </div>
                <div class="content">
                    <h3>HP Laptop</h3>
                    <div class="price">£250.00 <span>£300.00</span></div>
                </div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-17%</span>
            <div class="image">
                <img src="images/product05.png" alt="">
                <div class="icons">
                    <a href="#"class="fas fa-heart"></a>
                    <a href="#"class="cart-btn">add to cart</a>
                    <a href="#"class="fas fa-share"></a>
                </div>
                <div class="content">
                    <h3>HP Laptop</h3>
                    <div class="price">£250.00 <span>£300.00</span></div>
                </div>
            </div>
        </div>

        <div class="box">
            <span class="discount">-10%</span>
            <div class="image">
                <img src="images/product06.png" alt="">
                <div class="icons">
                    <a href="#"class="fas fa-heart"></a>
                    <a href="#"class="cart-btn">add to cart</a>
                    <a href="#"class="fas fa-share"></a>
                </div>
                <div class="content">
                    <h3>HP Laptop</h3>
                    <div class="price">£250.00 <span>£300.00</span></div>
                </div>
            </div>
        </div>

    </div>
</section>

<!-- product section end -->

<!-- review section start -->

<section class="review" id="review">
    <h1 class="heading">customer's <span>review</span></h1>

    <div class="box-container">
        <div class="box">
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <p>jjhashjdnhjwsd</p>

            <div class="user">
                <img src="" alt="">
                <div class="user-info">
                    <h3>john deo</h3>
                    <span>happy customer</span>
                </div>
            </div>
            <span class="fas fa-quote-right"></span>
        </div>

        <div class="box">
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <p>ewjwekjdwnej</p>

            <div class="user">
                <img src="" alt="">
                <div class="user-info">
                    <h3>Donald</h3>
                    <span>happy customer</span>
                </div>
            </div>
            <span class="fas fa-quote-right"></span>
        </div>

        <div class="box">
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <p>jjhashjdnhjwahsd</p>

            <div class="user">
                <img src="" alt="">
                <div class="user-info">
                    <h3>Henry deo</h3>
                    <span>happy customer</span>
                </div>
            </div>
            <span class="fas fa-quote-right"></span>
        </div>

        <div class="box">
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <p>aassssssssssssss</p>

            <div class="user">
                <img src="" alt="">
                <div class="user-info">
                    <h3>Henry deo</h3>
                    <span>happy customer</span>
                </div>
            </div>
            <span class="fas fa-quote-right"></span>
        </div>


    </div>
</section>

<!-- review section end -->

<!-- contact section start -->

<section class="contact" id="contact">
    <h1 class="heading"><span>contact</span> us</h1>
    <div class="row">
        <form action="">
            <input type="text" placeholder="name" class="box">
            <input type="email" placeholder="email" class="box">
            <input type="number" placeholder="number" class="box">
            <textarea name="" class="box" placeholder="message" id="" cols="30" rows="10"></textarea>
            <input type="submit" value="send message"class="btn">
        </form>

        <div class="image">
            <img src="images/Mail-sent.svg" alt="">
        </div>
    </div>

</section>
<!-- contact section end -->


<!-- Footer section start -->
<section class="footer">
    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="#">home</a>
            <a href="#">about</a>
            <a href="#">products</a>
            <a href="#">review</a>
            <a href="#">contact</a>
        </div>

        <div class="box">
            <h3>extra links</h3>
            <a href="#">my account</a>
            <a href="#">my order</a>
            <a href="#">my favorite</a>
        </div>

        <div class="box">
            <h3>locations</h3>
            <a href="#">United Kindom</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#">832748327</a>
            <a href="#">exaple@gmail.com</a>
            <a href="#">Location example</a>
            <img src="" alt="">
        </div>
    </div>

    <div class="credit">created by <span>Group</span>| all rights reserved</div>
</section>
<!-- Footer section end -->



    
</body>
</html>